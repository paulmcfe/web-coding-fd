    </main>
    <footer role="contentinfo">
        Copyright <?php echo date('Y'); ?> Logophilia Limited
    </footer>
    <script src="/js/data.js"></script>
    <script src="/js/user.js"></script>
</body>
</html>