<?php
    include_once '../private/common/initialization.php';
    $page_title = 'Your Account Was Deleted!';
    include_once 'common/top.php';    
?>
            <p>
                Sorry to see you go.</a>
            </p>
<?php
    include_once 'common/sidebar.php';
    include_once 'common/bottom.php';
?>
