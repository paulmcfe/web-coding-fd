var TAB = '    ';         // The number of spaces you want your CSS code indented
var customButton = {};    // Object to store the custom button's values
customButton.styles = {}; // Nested object to store the custom button's CSS property-value pairs
var hoverGradient = '';   // Holds the CSS code for the gradient
var hoverStyles = '';     // Holds the CSS code for the hover effect

// Define the default button values
var defaultButton = {};
defaultButton.text = 'Button';
defaultButton.gradient = true;
defaultButton.hover = true;
defaultButton.styles = {};
defaultButton.styles['background-color'] = 'hsl(0, 68%, 30%)';
defaultButton.styles['background-image'] = 'linear-gradient(to bottom, hsl(0, 68%, 50%) 0%, hsl(0, 68%, 30%) 100%)';
defaultButton.styles['border-color'] = 'hsl(0, 0%, 0%)';
defaultButton.styles['border-radius'] = '10px';
defaultButton.styles['border-style'] = 'solid';
defaultButton.styles['border-width'] = '0px';
defaultButton.styles['color'] = 'hsl(0, 0%, 100%)';
defaultButton.styles['font-family'] = 'Verdana, sans-serif';
defaultButton.styles['font-size'] = '1.25rem';
defaultButton.styles['font-style'] = 'normal';
defaultButton.styles['font-variant'] = 'normal';
defaultButton.styles['font-weight'] = 'normal';
defaultButton.styles['letter-spacing'] = '1.5px';
defaultButton.styles['padding-bottom'] = '10px';
defaultButton.styles['padding-left'] = '20px';
defaultButton.styles['padding-right'] = '20px';
defaultButton.styles['padding-top'] = '7px';
/*
 * ========================================================== *
 * setButtonValues(button)                                    *
 *     button - A button object                               *
 *     This function takes the data from the button object    *
 *     and uses them to set the values of the app's controls. *
 * ========================================================== *
 */
function setButtonValues(button) {

    // Set the Button Text value
    $('input[id=button-text]').val(button.text)
    $('input[id=button-text]').textinput('refresh', true);

    // Set the Gradient value
    if (button.gradient) {
        $('input[id=gradient]').prop('checked', true);
    } else {
        $('input[id=gradient]').prop('checked', false);
    }
    $('input[id=gradient]').flipswitch('refresh', true)

    // Set the Hover value
    if (button.hover) {
        $('input[id=hover]').prop('checked', true);
    } else {
        $('input[id=hover]').prop('checked', false);
    }
    $('input[id=hover]').flipswitch('refresh', true)

    // Loop through the styles
    for (var propertyName in button.styles) {

        // Skip the background-image property, which doesn't have a setting
        if (propertyName !== 'background-image') {

            // Set the control ID from the property name
            var propertyID = '#' + propertyName;

            // Get the current property value
            var propertyValue = button.styles[propertyName];

            // Is it a color property?
            if (propertyName.includes('color')) {
                
                // If so, apply the color to the color picker
                $(propertyID).spectrum('set', propertyValue);                
            }
            // Otherwise, is the property associated with a <select> tag?
            else if ($(propertyID)[0].tagName === 'SELECT') {
                
                // If so, is it a SelectMenu widget?
                if ($(propertyID).attr('data-role') === 'selectmenu') {
                    
                    // If so, set the SelectMenu's selected option
                    $('select[id=' + propertyName + '] > option[value="' + propertyValue + '"]').attr('selected', true)
                    $('select[id=' + propertyName + ']').selectmenu('refresh', true);
                } else {
                    
                    // Otherwise, set the FlipSwitch's selected option
                    $('select[id=' + propertyName + '] > option[value="' + propertyValue + '"]').attr('selected', true)
                    $('select[id=' + propertyName + ']').flipswitch('refresh', true);
                }
            } else {
                
                // For all other inputs, first remove the unit (rem or px)
                propertyValue = propertyValue.replace(/rem|px/, '');

                // Now set the control's value
                $('input[id=' + propertyName + ']').val(propertyValue);
                $('input[id=' + propertyName + ']').textinput('refresh', true);
            }
        }
    }
}
/*
 * ======================================================= *
 * getButtonValues()                                       *
 *     This function gets the values of the app's controls *
 *     and stores them in the customButton object.         *
 * ======================================================= *
 */
function getButtonValues() {

    // Reference all the controls (that is, all the <input> and <select> tags)
    var $controls = $('article').find('input, select');

    // Loop through all the controls
    $controls.each(function() {

        // In most cases, the ID of each setting is also the CSS property name
        var cssProperty = $(this).attr('id');

        // Use a switch() to handle the exceptions
        switch (cssProperty) {

            // Write the button text
            case 'button-text':
                
                // Get the user's button text
                var newButtonText  = $(this).val();

                // Apply the text to the button
                $('.btn').text(newButtonText);
                
                // Store the button text
                customButton.text = newButtonText;
                
                break;

            // Apply a gradient to the button background
            case 'gradient':

                // Is the Gradient Flipswitch widget set to On?
                if($('#gradient').prop('checked')) {

                    // Turn on the button's gradient flag
                    customButton.gradient = true;
                } else {

                    // Turn off the button's gradient flag
                    customButton.gradient = false;
                }
                
                // Build the gradient CSS
                buildGradient(customButton);
                
                break;

            // Apply a hover effect to the button background
            case 'hover':

                // Is the Hover Flipswitch widget set to On?
                if($('#hover').prop('checked')) {

                    // Turn on the button's hover flag
                    customButton.hover = true;
                } else {

                    // Turn off the button's hover flag
                    customButton.hover = false;
                }
                
                // Build the hover CSS
                buildHover(customButton);
                
                break;

            // For everything else, store the property-value
            // pair in the customButton.styles object
            default:
            
                // First, check for a unit associated with the property
                var unit = $(this).attr('data-unit');
                
                // Does the unit exist?
                if(unit != null) {

                    // If so, add it to the property value
                    if(cssProperty === 'box-shadow') {
                        customButton.styles[cssProperty] = $(this).val() + unit + ' 3px 3px #666';
                    } else {
                        customButton.styles[cssProperty] = $(this).val() + unit;
                    }
                } else {

                    // Otherwise, just store the property value
                    customButton.styles[cssProperty] = $(this).val();
                }
        }
    });
}
/*
 * =========================================================== *
 * generateButtonValues(button)                                *
 *     button - A button object                                *
 *     This function takes the data from the button object and *
 *     uses them to generate the button's custom CSS code.     *
 * =========================================================== *
 */
function generateButtonCode(button) {

    // Set the button text
    $('.btn').text(button.text);

    // Build the gradient code
    buildGradient(button);

    // Build the hover code
    buildHover(button);

    // Sort the styles by property name
    var alphaStyles = {};
    Object.keys(button.styles).sort().forEach(function(propertyName) {
        alphaStyles[propertyName] = button.styles[propertyName];
    });

    // Build the CSS string for the .btn class
    var strCSS = "\n.btn {\n";
    for (var propertyName in alphaStyles) {
        strCSS += TAB + propertyName + ": " + alphaStyles[propertyName] + ";\n";
    }
    strCSS += "}\n";
    strCSS += hoverStyles;

    // Add the code to the CSS Code section
    $('#css-code').text(strCSS);

    // Build the <style> tag
    var strStyleTag = '<style id="button-css" type="text/css">' + strCSS + '</style>';

    // Replace the current <style> tag with the new one
    $('#button-css').replaceWith(strStyleTag);

    // Adjust the <article> padding-top so that it clears the new header size
    $('article').css('padding-top', $('header').height() + 2);
}
/*
 * ================================================= *
 * buildGradient(button)                             *
 *     button - A button object                      *
 *     This function generates the CSS code for      * 
 *     the button's linear gradient effect (if any). *
 * ================================================= *
 */
function buildGradient(button) {

    // Is the gradient flag on?
    if(button.gradient) {
        // If so, set the gradient top color equal to the background color's luminance + 20%
        // Step 1: Get the background color
        var gradientBottomColor = button.styles['background-color'];

        // Step 2: Split the hsl() function on the commas
        var colorArray = gradientBottomColor.split(', ');

        // The background color's luminance value is in the third array item
        // Step 3: Parse that value as an integer and then add 20
        var gradientLuminance = parseInt(colorArray[2]) + 20;
        if (gradientLuminance > 100) gradientLuminance = 100;

        // Step 4: Build the hsl() string for the gradient's top color
        var gradientTopColor = colorArray[0] + ', '  + colorArray[1] + ', ' + gradientLuminance + '%)';

        // Step 5: Build the background-image value
        var linearGradient = 'linear-gradient(to bottom, ' + gradientTopColor + ' 0%, ' + gradientBottomColor + ' 100%)';
        hoverGradient = 'linear-gradient(to bottom, ' + gradientBottomColor + ' 0%, ' + gradientTopColor + ' 100%)';

        // Step 6: Add the background-style to the array
        button.styles['background-image'] = linearGradient;
    } else {

        // If not, set background-image to none to cancel any previous gradient
        button.styles['background-image'] = 'none';
    }
}
/*
 * ============================================ *
 * buildHover(button)                           *
 *     button - A button object                 *
 *     This function generates the CSS code for * 
 *     the button's hover effect (if any).      *
 * ============================================ *
 */
function buildHover(button) {

    // Is the hover flag on?
    if(button.hover) {
        
        // If so, build the .btn:hover pseudo-class
        hoverStyles = ".btn:hover {\n";
        hoverStyles += TAB + "background-color: " + button.styles['background-color'] + ";\n";
        hoverStyles += TAB + "background-image: " + hoverGradient + ";\n";
        hoverStyles += "}\n";
    } else {

        // If not, set background-image to the null string to cancel any previous gradient
        hoverStyles = '';
    }
}
/*
 * ========================================================= *
 * initializeColorPickers()                                  *
 *     This function initializes the Spectrum color pickers  * 
 *     for the button's text, background, and border colors. *
 * ========================================================= *
 */
function initializeColorPickers() {

    // Text color picker
    	$("#color").spectrum({
    	    color: "hsl(0, 0%, 100%)",
    	    flat: false,
    	    showInput: true,
    	    showAlpha: true,
    	    className: "full-spectrum",
    	    showButtons: false,
    	    showInitial: true,
    	    showPalette: true,
    	    showSelectionPalette: true,
    	    maxSelectionSize: 10,
    	    preferredFormat: "hsl",
    	    localStorageKey: "spectrum.demo",
    	    palette: [
    	        ["rgb(152, 0, 0)", "rgb(255, 0, 0)", "rgb(255, 153, 0)", "rgb(255, 255, 0)", "rgb(0, 255, 0)",
    	        "rgb(0, 255, 255)", "rgb(74, 134, 232)", "rgb(0, 0, 255)", "rgb(153, 0, 255)", "rgb(255, 0, 255)"],
    	        ["rgb(230, 184, 175)", "rgb(244, 204, 204)", "rgb(252, 229, 205)", "rgb(255, 242, 204)", "rgb(217, 234, 211)",
    	        "rgb(208, 224, 227)", "rgb(201, 218, 248)", "rgb(207, 226, 243)", "rgb(217, 210, 233)", "rgb(234, 209, 220)",
    	        "rgb(221, 126, 107)", "rgb(234, 153, 153)", "rgb(249, 203, 156)", "rgb(255, 229, 153)", "rgb(182, 215, 168)",
    	        "rgb(162, 196, 201)", "rgb(164, 194, 244)", "rgb(159, 197, 232)", "rgb(180, 167, 214)", "rgb(213, 166, 189)",
    	        "rgb(204, 65, 37)", "rgb(224, 102, 102)", "rgb(246, 178, 107)", "rgb(255, 217, 102)", "rgb(147, 196, 125)",
    	        "rgb(118, 165, 175)", "rgb(109, 158, 235)", "rgb(111, 168, 220)", "rgb(142, 124, 195)", "rgb(194, 123, 160)",
    	        "rgb(166, 28, 0)", "rgb(204, 0, 0)", "rgb(230, 145, 56)", "rgb(241, 194, 50)", "rgb(106, 168, 79)",
    	        "rgb(69, 129, 142)", "rgb(60, 120, 216)", "rgb(61, 133, 198)", "rgb(103, 78, 167)", "rgb(166, 77, 121)",
    	        "rgb(91, 15, 0)", "rgb(102, 0, 0)", "rgb(120, 63, 4)", "rgb(127, 96, 0)", "rgb(39, 78, 19)",
    	        "rgb(12, 52, 61)", "rgb(28, 69, 135)", "rgb(7, 55, 99)", "rgb(32, 18, 77)", "rgb(76, 17, 48)"]
    	    ]
    	});
    	
    // Background color picker
    	$("#background-color").spectrum({
    	    color: "hsl(0, 68%, 30%)",
    	    flat: false,
    	    showInput: true,
    	    showAlpha: true,
    	    className: "full-spectrum",
    	    showButtons: false,
    	    showInitial: true,
    	    showPalette: true,
    	    showSelectionPalette: true,
    	    maxSelectionSize: 10,
    	    preferredFormat: "hsl",
    	    localStorageKey: "spectrum.demo",
    	    palette: [
    	        ["rgb(152, 0, 0)", "rgb(255, 0, 0)", "rgb(255, 153, 0)", "rgb(255, 255, 0)", "rgb(0, 255, 0)",
    	        "rgb(0, 255, 255)", "rgb(74, 134, 232)", "rgb(0, 0, 255)", "rgb(153, 0, 255)", "rgb(255, 0, 255)"],
    	        ["rgb(230, 184, 175)", "rgb(244, 204, 204)", "rgb(252, 229, 205)", "rgb(255, 242, 204)", "rgb(217, 234, 211)",
    	        "rgb(208, 224, 227)", "rgb(201, 218, 248)", "rgb(207, 226, 243)", "rgb(217, 210, 233)", "rgb(234, 209, 220)",
    	        "rgb(221, 126, 107)", "rgb(234, 153, 153)", "rgb(249, 203, 156)", "rgb(255, 229, 153)", "rgb(182, 215, 168)",
    	        "rgb(162, 196, 201)", "rgb(164, 194, 244)", "rgb(159, 197, 232)", "rgb(180, 167, 214)", "rgb(213, 166, 189)",
    	        "rgb(204, 65, 37)", "rgb(224, 102, 102)", "rgb(246, 178, 107)", "rgb(255, 217, 102)", "rgb(147, 196, 125)",
    	        "rgb(118, 165, 175)", "rgb(109, 158, 235)", "rgb(111, 168, 220)", "rgb(142, 124, 195)", "rgb(194, 123, 160)",
    	        "rgb(166, 28, 0)", "rgb(204, 0, 0)", "rgb(230, 145, 56)", "rgb(241, 194, 50)", "rgb(106, 168, 79)",
    	        "rgb(69, 129, 142)", "rgb(60, 120, 216)", "rgb(61, 133, 198)", "rgb(103, 78, 167)", "rgb(166, 77, 121)",
    	        "rgb(91, 15, 0)", "rgb(102, 0, 0)", "rgb(120, 63, 4)", "rgb(127, 96, 0)", "rgb(39, 78, 19)",
    	        "rgb(12, 52, 61)", "rgb(28, 69, 135)", "rgb(7, 55, 99)", "rgb(32, 18, 77)", "rgb(76, 17, 48)"]
    	    ]
    	});
    	
    // Border color picker
    	$("#border-color").spectrum({
    	    color: "hsl(0, 0%, 0%)",
    	    flat: false,
    	    showInput: true,
    	    showAlpha: true,
    	    className: "full-spectrum",
    	    showButtons: false,
    	    showInitial: true,
    	    showPalette: true,
    	    showSelectionPalette: true,
    	    maxSelectionSize: 10,
    	    preferredFormat: "hsl",
    	    localStorageKey: "spectrum.demo",
    	    palette: [
    	        ["rgb(152, 0, 0)", "rgb(255, 0, 0)", "rgb(255, 153, 0)", "rgb(255, 255, 0)", "rgb(0, 255, 0)",
    	        "rgb(0, 255, 255)", "rgb(74, 134, 232)", "rgb(0, 0, 255)", "rgb(153, 0, 255)", "rgb(255, 0, 255)"],
    	        ["rgb(230, 184, 175)", "rgb(244, 204, 204)", "rgb(252, 229, 205)", "rgb(255, 242, 204)", "rgb(217, 234, 211)",
    	        "rgb(208, 224, 227)", "rgb(201, 218, 248)", "rgb(207, 226, 243)", "rgb(217, 210, 233)", "rgb(234, 209, 220)",
    	        "rgb(221, 126, 107)", "rgb(234, 153, 153)", "rgb(249, 203, 156)", "rgb(255, 229, 153)", "rgb(182, 215, 168)",
    	        "rgb(162, 196, 201)", "rgb(164, 194, 244)", "rgb(159, 197, 232)", "rgb(180, 167, 214)", "rgb(213, 166, 189)",
    	        "rgb(204, 65, 37)", "rgb(224, 102, 102)", "rgb(246, 178, 107)", "rgb(255, 217, 102)", "rgb(147, 196, 125)",
    	        "rgb(118, 165, 175)", "rgb(109, 158, 235)", "rgb(111, 168, 220)", "rgb(142, 124, 195)", "rgb(194, 123, 160)",
    	        "rgb(166, 28, 0)", "rgb(204, 0, 0)", "rgb(230, 145, 56)", "rgb(241, 194, 50)", "rgb(106, 168, 79)",
    	        "rgb(69, 129, 142)", "rgb(60, 120, 216)", "rgb(61, 133, 198)", "rgb(103, 78, 167)", "rgb(166, 77, 121)",
    	        "rgb(91, 15, 0)", "rgb(102, 0, 0)", "rgb(120, 63, 4)", "rgb(127, 96, 0)", "rgb(39, 78, 19)",
    	        "rgb(12, 52, 61)", "rgb(28, 69, 135)", "rgb(7, 55, 99)", "rgb(32, 18, 77)", "rgb(76, 17, 48)"]
    	    ]
    	});
}